/* Eric Paulz
   epaulz
   Lab 1
   CPSC 1021-004
   Glyder
 */

#include <stdio.h>

int main(){

	printf("H   H   EEEEE   L       L        OOO \n");
	printf("H   H   E       L       L       O   O\n");
	printf("HHHHH   EEEE    L       L       O   O\n");
	printf("H   H   E       L       L       O   O\n");
	printf("H   H   EEEEE   LLLLL   LLLLL    OOO \n");

	printf("\n\n\n");

	printf("W       W    OOO    RRRRR   L       DDDD    !!\n");
	printf("W       W   O   O   R   R   L       D   D   !!\n");
	printf(" W  W  W    O   O   RRRR    L       D   D   !!\n");
	printf("  W W W     O   O   R R     L       D   D   !!\n");
	printf("   W W       OOO    R   R   LLLLL   DDDD    oo\n");

	return 0;
}
