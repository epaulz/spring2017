/* Eric Paulz
 * epaulz
 * CPSC 1021-004
 * Lab #4
 * TA: Nick Glyder
 */

#include <iostream>
#include <iomanip>

// struct declaration
typedef struct{
	double x;
	double y;
} point_t;

// function prototype
int checkPoint(point_t *p, point_t *test);
