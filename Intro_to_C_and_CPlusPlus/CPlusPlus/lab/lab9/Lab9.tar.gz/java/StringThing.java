class StringThing {
  public static void main(String[] args) {
    String cat = new String("cat");
    String dog = new String("dog");

    String combo = new String(cat + dog);
    System.out.println(combo);
  }
}
