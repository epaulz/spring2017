month = "10"
day = "5"
year = "1993"

date = month + " " + day + ", " + year
print date

date = int(month+day+year)
print date
