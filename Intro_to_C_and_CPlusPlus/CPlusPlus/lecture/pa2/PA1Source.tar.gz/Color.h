#ifndef COLOR_H
#define COLOR_H

class Color
{
  private:
    

  public:

   
    
    
};

#endif
