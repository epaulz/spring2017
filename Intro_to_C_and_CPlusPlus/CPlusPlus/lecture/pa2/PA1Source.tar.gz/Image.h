#ifndef IMAGE_H
#define IMAGE_H
#include <fstream>
#include <iostream>
#include <string>
#include "Pixel.h"
#include "Header.h"

class Image
{
  private:
   

  public:

   

};
#endif
