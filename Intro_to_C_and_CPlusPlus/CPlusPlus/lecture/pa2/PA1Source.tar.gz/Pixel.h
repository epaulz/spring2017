#ifndef PIXEL_H
#define PIXEL_H
#include "color.h"
#include "point.h"
#include <fstream>
using namespace std;


class Pixel
{
  private:
   
  public:

    

};
#endif
