#ifndef POINT_H
#define POINT_H

class Point
{
    private:
    

    public:
    
    
};
#endif
