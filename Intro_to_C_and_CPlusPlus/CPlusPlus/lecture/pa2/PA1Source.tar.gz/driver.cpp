#include <iostream>
#include "Image.h"
using namespace std;

/*The prototype for the client function that determines if the given
 *point is within the parameter of the trianle*/
int main(int argc, char *argv[])
{
  ofstream outPut(argv[2]);
  ifstream inPut(argv[1]);
    
  /*Create an instance of the Image class and Point to represent 
   *the three points that defines the triangle.  Also put other 
   *variables needed here.*/
  
    

  if(argc != 3)
  {
    cout << "USAGE ERROR:  ./executable outPutFileName";
    exit(EXIT_FAILURE);
  }
  if(inPut.fail())
  {
    cout << argv[1] << " did not open successfully\n";
  }

  if(outPut.fail())
  {
    cout << argv[2] << " did not open successfully\n";
  }
    
  /*read the data from the input file here*/

  
    
    
    
  /*Using the instance of image created above call the function
   *to set the width and height for the header.  Using the 
   *instance of image call the funtion used to print the header*/

 
    
    
    
  /*using nested for loops call the client function to test if
   *the given point is within the parameters of the triangle.  
   *Using the instance of image set the color of the pixels RGB
   *channels and then call the function to print the Pixel to 
   *the output file.*/

    
    
 
    
    
    
  inPut.close();
  outPut.close();

  return 0;
}

/*Implement the function that determines if a given point is 
 *within the parameter of the triangle*/
